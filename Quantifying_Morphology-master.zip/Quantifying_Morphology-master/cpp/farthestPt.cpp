// Finds the farthest point in a set of points, brute force method

#include <fstream>
#include <iostream>
#include <sstream>

int main(char* 
